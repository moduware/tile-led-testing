window.lastTimeRecieved = 0;
window.lastData = -1;

/** ================ Handlers == */
function nativeDataUpdateHandler(data) {
}
